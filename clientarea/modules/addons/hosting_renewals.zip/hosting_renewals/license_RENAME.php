<?php
/*
 * LICENSE:
 * Please provide your Hosting Renewals Module For WHMCS license below
 */
$hosting_renewals_licensekey="ModulesGarden_HostingRenewals_xxxxxxxxxxxx";
